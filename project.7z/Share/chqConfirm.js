function confirmReq()
{
	alert('hii');
String val= document.chqReqForm.chqReq.value;
document.write(val);

}