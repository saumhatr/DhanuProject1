package com.capGemini.banking.controller;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.capGemini.banking.dto.AccountDto;
import com.capGemini.banking.dto.CustomerDto;
import com.capGemini.banking.dto.UserDto;
import com.capGemini.banking.exception.BankingException;
import com.capGemini.banking.service.BankingService;
import com.capGemini.banking.service.BankingServiceImpl;

@WebServlet("*.do")
public class BankingController extends HttpServlet {
	private static final long serialVersionUID = 1L;

	CustomerDto cust=new CustomerDto();
	AccountDto acc=new AccountDto();
	UserDto uDto=new UserDto();
BankingService service=new BankingServiceImpl();

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		processRequest(request,response);
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		processRequest(request,response);
	}
private void processRequest(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException
{
	String path=request.getServletPath();
	switch(path){
	case "/bank.do":
		response.sendRedirect("login.jsp");
		break;
	case "/login.do":
		String password=request.getParameter("password");
		String userid=request.getParameter("userid");
		int id=Integer.parseInt(userid);
		String admin=request.getParameter("admin");
		System.out.println(password);
		System.out.println(id);
		if(admin.equals("admin"))
		{
			if(userid.equals("101"))
				if(password.equals("vandu"))
				{
					response.sendRedirect("CreateAccount.jsp");
				}
			
			
		}
		else if(admin.equals("user"))
		{
			response.sendRedirect("Home.jsp");
		}
		else
		{
			response.sendRedirect("error.jsp");
		}
		
		break;
	case "/createaccount.do":
		String fname=request.getParameter("fname");
		String mname=request.getParameter("mname");
		String lname=request.getParameter("lname");
		String fullName=fname + " " + mname + " " + lname ;
		String address=request.getParameter("address");
		String mobile=request.getParameter("number");
		String emailid=request.getParameter("email");
		String accType=request.getParameter("saving");
		String openBal=request.getParameter("balance");
		Double openBalDouble=Double.parseDouble(openBal);
		
		cust.setCustomer_name(fullName);
		cust.setAddress(address);
		cust.setMobileNo(mobile);
		cust.setEmail(emailid);
		acc.setAccount_Type(accType);
		acc.setAccount_Balance(openBalDouble);
		
		int accId;
		try {
			accId = service.addCustDetails(cust,acc);
		UserDto	uDto=service.getUserDto(accId);
		System.out.println(uDto);
			if(accId>0)
			{
				
				request.setAttribute("id", accId);
				request.setAttribute("userid", uDto);
				
				RequestDispatcher dispatch=request.getRequestDispatcher("welcome.jsp");
				dispatch.forward(request, response);
			}
		} catch (BankingException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		break;
	case "updateCustomerDetails.do":
		
		break;
		
		
	}
	/*if(path.equals("/bank.do"))
	{
		response.sendRedirect("login.jsp");
	}
	if(path.equals("/login.do"))
	{
		String password=request.getParameter("password");
		String userid=request.getParameter("userid");
	int id=Integer.parseInt(userid);
		String admin=request.getParameter("admin");
		System.out.println(password);
		System.out.println(id);
		if(admin.equals("admin"))
		{
			if(userid.equals("101"))
				if(password.equals("vandu"))
				{
					response.sendRedirect("CreateAccount.jsp");
				}
			
			
		}
		else if(admin.equals("user"))
		{
			response.sendRedirect("Home.jsp");
		}
		else
		{
			response.sendRedirect("error.jsp");
		}
			
	}
	if(path.equals("/createaccount.do"))
	{
		String fname=request.getParameter("fname");
		String mname=request.getParameter("mname");
		String lname=request.getParameter("lname");
		String fullName=fname + " " + mname + " " + lname ;
		String address=request.getParameter("address");
		String mobile=request.getParameter("number");
		String emailid=request.getParameter("email");
		String accType=request.getParameter("saving");
		String openBal=request.getParameter("balance");
		Double openBalDouble=Double.parseDouble(openBal);
		
		cust.setCustomer_name(fullName);
		cust.setAddress(address);
		cust.setMobileNo(mobile);
		cust.setEmail(emailid);
		acc.setAccount_Type(accType);
		acc.setAccount_Balance(openBalDouble);
		
		int accId;
		try {
			accId = service.addCustDetails(cust,acc);
		UserDto	uDto=service.getUserDto(accId);
		System.out.println(uDto);
			if(accId>0)
			{
				
				request.setAttribute("id", accId);
				request.setAttribute("userid", uDto);
				
				RequestDispatcher dispatch=request.getRequestDispatcher("welcome.jsp");
				dispatch.forward(request, response);
			}
		} catch (BankingException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
		
	}*/
}
}
