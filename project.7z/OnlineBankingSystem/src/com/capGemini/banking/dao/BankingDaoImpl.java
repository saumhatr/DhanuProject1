package com.capGemini.banking.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import com.capGemini.banking.dto.AccountDto;
import com.capGemini.banking.dto.CustomerDto;
import com.capGemini.banking.dto.UserDto;
import com.capGemini.banking.exception.BankingException;
import com.capGemini.banking.util.BankingUtil;



public class BankingDaoImpl implements BankingDao{
Connection conn=null;
PreparedStatement ps=null;
CustomerDto cust=new CustomerDto();
AccountDto acc=new AccountDto();

	public BankingDaoImpl() {
		
	}

	@Override
	public int addCustDetails(CustomerDto cust,AccountDto acc) throws BankingException {
		conn=BankingUtil.obtainConnection();
		int accId=getAccountId();
		String query="INSERT INTO Customer values(?,?,?,?,?,?)";
		try {
			ps=conn.prepareStatement(query);
			ps.setLong(1, accId);
			ps.setString(2, cust.getCustomer_name());
			ps.setString(3, cust.getEmail());
			ps.setString(4, cust.getAddress());
			ps.setString(5, cust.getPancard());
			ps.setString(6, cust.getMobileNo());
			
			int status=ps.executeUpdate();
			int statusAcc=0;
			if(status>0)
			{
				String query1="INSERT INTO AccountMaster values(?,?,?,sysdate)";
				ps=conn.prepareStatement(query1);
				ps.setLong(1, accId);
			ps.setString(2,acc.getAccount_Type());
			ps.setDouble(3, acc.getAccount_Balance());
			 statusAcc=ps.executeUpdate();
			
			}
			if(statusAcc>0)
			{
				int userId=getUserId();
				String password=generatePassword(8,true);
				String query2="INSERT INTO UserTable (Account_ID,user_id,login_password) values(?,?,?)";
				ps=conn.prepareStatement(query2);
				ps.setLong(1, accId);
				ps.setInt(2, userId);
				ps.setString(3, password);
				int UserStatus=ps.executeUpdate();
				
			}
			else
			{
				System.out.println("not inserted");
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally
		{
			try {
				ps.close();
				conn.close();
			} catch (SQLException e) {
				
				e.printStackTrace();
				throw new BankingException("In Finally");
			}
		}
		
		return accId;
	}
	public int getAccountId()
	{
		int accId=0;
		String query="SELECT accountId_seq.NEXTVAL from dual";
		try {
			conn=BankingUtil.obtainConnection();
			ps=conn.prepareStatement(query);
			ResultSet res=ps.executeQuery();
			while(res.next()){
				accId=res.getInt(1);
			}
		} catch (SQLException e) {
			
			e.printStackTrace();
		}
		
		return accId;
	}
	public int getUserId()
	{
		int userId=0;
		String query="SELECT userId_seq.NEXTVAL from dual";
		try {
			conn=BankingUtil.obtainConnection();
			ps=conn.prepareStatement(query);
			ResultSet res=ps.executeQuery();
			while(res.next()){
				userId=res.getInt(1);
			}
		} catch (SQLException e) {
			
			e.printStackTrace();
		}
		
		return userId;
	}
	public String generatePassword(int length,boolean special)
	{
		String password=null;
		int iteration=0;
		double randomNumber = 0;
		while(iteration<length)
		{
			 randomNumber=((Math.floor(Math.random()*100)) % 94)+33;
		
		if(!special)
		{
			if((randomNumber >=33) && (randomNumber <=47)) { continue; }
			if((randomNumber >=58) && (randomNumber <=64)) { continue; }
			if((randomNumber >=91) && (randomNumber <=96)) { continue; }
			if((randomNumber >=123) && (randomNumber <=126)) { continue; }
		}
		iteration++;
		char a=(char)randomNumber;
		password+=String.valueOf(a);
		}
		String password1=password.substring(4,length+4);
		return password1;
		
	}
	
	public UserDto getUserDto(long accId)
	{
		conn=BankingUtil.obtainConnection();
		String query="SELECT user_id,login_password FROM UserTable where Account_ID=?";
		UserDto uDto=new UserDto();
		try {
			ps=conn.prepareStatement(query);
			ps.setLong(1, accId);
			ResultSet rs=ps.executeQuery();
			
			while(rs.next())
			{
				
				uDto.setUser_id(rs.getInt("user_id"));
				uDto.setLogin_password(rs.getString("login_password"));
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return uDto;
		
	}
}
